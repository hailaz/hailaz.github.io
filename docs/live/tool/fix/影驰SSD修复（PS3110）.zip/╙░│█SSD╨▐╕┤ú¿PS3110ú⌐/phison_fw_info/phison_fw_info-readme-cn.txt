本程序用于在文件中搜索和保存Phison 3105/3108/3109/3110/3111/3112/5007..5018等SSD控制器的固件镜像，以及输出它们的一些信息。

运行程序时需要指定一个文件。
例如：
phison_fw_info "Patriot Tool Box_Complete_v1.15-1.exe"
phison_fw_info "Patriot Tool Box_Complete_v1.15-1.exe" f - 完整格式描述
phison_fw_info "Patriot Tool Box_Complete_v1.15-1.exe" f2 - 扩展格式描述
phison_fw_info "Patriot Tool Box_Complete_v1.15-1.exe" s - 将每个镜像保存为单独的文件，文件名格式如：SBFM11.1-20170901-161606.bin
phison_fw_info "Patriot Tool Box_Complete_v1.15-1.exe" su - 将每个镜像保存为单独的文件，文件名格式如：SBFM11.1_01092017.bin
参数 f/s 可以组合使用

如果在没有参数的情况下运行，将显示帮助提示。

-------------------------------------------------------------------------------
Phison firmware info v0.31a (c) vlo
Firmware file : Patriot Tool Box_Complete_v1.15-1.exe
S9FM02.9 2017-02-13 15:58:00 461312 0x329BA8
S8FM08.3 2015-09-03 14:42:17 881664 0x39A5A8
S7F702f  2014-05-02 17:19:30 411136 0x4719A8
S7F703s  2014-09-11 16:02:42 263680 0x4D5FA8
S7F601f  2014-07-31 17:20:41 247296 0x5165A8
SAFM01.7 2016-03-02 11:10:06 1741312 0x552BA8
SAFM02.3 2016-12-14 13:16:29 1741312 0x6FBDA8
SAFM11.3 2016-08-22 10:58:14 1741312 0x8A4FA8
SAFM12.2 2016-11-22 18:22:08 1675776 0xA4E1A8
SBFM01.1 2017-08-24 20:04:06 1479168 0xBE73A8
SBFM11.1 2017-09-01 16:16:06 1479168 0xD505A8
SBFM21.1 2017-08-21 19:11:03 1479168 0xEB97A8
SBFM51.2 2017-07-25 19:04:54 1479168 0x10229A8
SBFM61.0 2017-03-28 13:40:58 1479168 0x118BBA8
SBFM71.1 2017-08-18 19:33:04 1479168 0x12F4DA8
SBFM81.1 2017-05-19 18:51:00 1479168 0x145DFA8
SBFM91.1 2017-08-24 19:56:54 1479168 0x15C71A8
End of file - exit
Found 17 firmware images!
-------------------------------------------------------------------------------
phison_fw_info2.exe UpgradeFW_CS105110_v2.00_20180328.exe f
Phison firmware info v0.2a (c) vlo
Firmware file : UpgradeFW_CS105110_v2.00_20180328.exe
--------------------
Offset    : 188AF0
Controller: S11
Version   : SBFM51.0
boot size : 724992 [0xB1000]
boot cs16 : A2F6
main size : 753664 [0xB8000]
main cs16 : 8A93
full size : 1479168 [0x169200]
Date/time : 2017-05-16 10:31:06
End of file - exit
Found 1 firmware images!
-------------------------------------------------------------------------------
