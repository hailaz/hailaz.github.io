该程序用于基于Phison PS3110控制器的SSD，利用指定的固件版本生成刷写工具。
其独特之处在于可以操作没有固件或固件无法启动的硬盘，即硬盘处于rom-mode模式。
此模式下硬盘的标志为型号TC58NC1000，固件版本SARM1.x，容量为4096扇区。
如果硬盘无法识别，为强制进入该模式，需要在主板上短接gpio0(fbc0)和3v3引脚。
同样也可用于正常模式下的硬盘，但数据会被永久删除。

套件包含三个必需文件：
build-s10-flasher.exe
build-s10-flasher.0
build-s10-flasher.2
另外还需要完整固件文件，可在 http://www.usbdev.ru/files/phison/ps3110fw/ 下载，或从phison toolbox/complete等提取。
如有需要，可用ps_read将主固件替换为已保存的版本。

套件中还包含phison_eraseall工具（仅适用于rom mode下型号为"TC58NC1000"的Phison S10硬盘）。
该工具用于预先擦除闪存，在某些情况下可避免刷写程序在30%时出现“Jump ISP Failed”错误。
使用前需将硬盘切换到rom mode。
与刷写工具不同，它支持通过USB连接硬盘。
使用后需短暂断开硬盘电源。
同样需要合适版本的完整固件文件。
用法：

phison_eraseall_rommode_s10 drive_num full_fw.bin
drive_num    - 硬盘编号
full_fw.bin  - 完整固件

不同版本的用途说明：
safm00.*/safm01.*/safm02.* - 适用于不同厂商（micron/sandisk/toshiba）的MLC闪存硬盘
safm22.* - 适用于“ufs” MLC闪存（toshiba）
safm32.* - 适用于1-2TB容量的MLC闪存硬盘
safm11.* - 适用于19nm toshiba TLC闪存
safm12.* - 适用于15nm toshiba TLC闪存
safm13.* - 适用于BiCS3 (3D) toshiba TLC闪存
safm16.* - 适用于无SLC缓存的BiCS3 (3D) toshiba TLC闪存

用法：

build-s10-flasher flasher.exe source_full_fw.bin [replace_main_fw.bin] [-s<drive_size>]

flasher.exe      - 生成的刷写工具文件
full_fw.bin      - 固件文件，长度不超过1741312（已知有1479168、1610240、1675776、1741312等）
main_fw.bin      - 可选，保存的主固件，大小为1216512
<drive_size>     - 硬盘容量（单位：扇区），用于设置非默认14%的OP空间
                   容量以扇区为单位（不是OP百分比），如果尝试刷写容量更小的硬盘会报错，容量更大的硬盘会被裁剪到指定容量。
                   指定容量不应超过“7%”对应的数值。
                   每种容量需单独生成刷写工具。
部分标准容量值：
 60G   117231408   14%
 64G   125045424   7%
120G   234441648   14%
128G   250069680   7%
240G   468862128   14%
256G   500118192   7%
480G   937703088   14%
512G  1000215216   7%
960G  1875385008   14%
1024G 2000409264   7%

例如：

build-s10-flasher SAFM02.3_03112016.exe SAFM02.3_03112016.BIN
build-s10-flasher SAFM02.3_03112016_256G.exe SAFM02.3_03112016.BIN -s500118192

----------------------------------------
关于生成的刷写工具的使用：

如果过程卡住或在30%时中断，有三种可能：
- 固件与闪存不匹配，请选择合适的固件
- 硬盘已刷写但未配置，可在IDE（非AHCI）模式或通过USB启动Windows并用repairs10.rar修复
- 有时只需短暂断开硬盘电源，然后立即用repairs10.rar修复
- 也可尝试将IMC闪存#0（通常有标签的那颗）总线短接，而不是短接gpio0和3v3进入rom mode。
  这种情况下可能会出现SMART属性列表为空的硬盘，可用phison_upd_smart.rar修复

刷写工具在msahci/storahci/rst（非rste？）驱动下的ahci模式下工作。pciide/intelide下不一定可用，其他驱动未测试。

附加文件链接：
http://www.usbdev.ru/?wpfb_dl=5221    - 固件包
http://vlo.name:3000/tmph/repairs10.rar    - ps3110硬盘刷写失败后修复工具
http://vlo.name:3000/tmph/phison_upd_smart.rar    - SMART属性修复工具
http://vlo.name:3000/tmph/ps_read033.rar    - 读取ps3110硬盘主固件（fw.bin）的工具