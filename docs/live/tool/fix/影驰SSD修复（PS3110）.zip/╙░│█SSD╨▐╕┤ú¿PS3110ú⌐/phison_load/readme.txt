Программа предназначена восстановления настроек smart у ssd дисков на контроллере Phison 3111, например Smartbuy Ignition+.

Системные требования - Windows XP/SP2 и выше, возможно использование x86 и x64 версий. Можно использовать Windows PE основанные на этих же версиях. Требуется запуск с правами администратора (под системами Vista/выше производится запрос на получение прав).
Диск должен быть подключен к SATA контроллеру (подключение через firewire не поддерживается), поддерживается работа со стандартными драйверами IDE и AHCI от Microsoft, Intel RST. Работоспособность с другими драйверами не проверялась. Наверняка не будет работать с драйверами контроллеров из раздела "SCSI and RAID controllers".
Так же возможна работа через некоторые usb-sata мосты, например asmedia asm105x/115x, jmicron jm[s]20329/539/578, initio inic1608 и некоторые другие.

Для запуска программе нужно указать номер диска в системе в виде параметра, его можно посмотреть в консоли "Управление компьютером"->"Управление дисками" и имя файла с настройками.
Например:
phison_load_cfg_smart_s11 2 smart_phison.bin

варианты настроек:
smart_default.bin	- умолчательный от phison (большинство дисков под разными марками)
smart_apacer.bin	- apacer (as330,as510) - слегка расширенный
smart_kingspec.bin	- kingspec/"inic6081" - значения большинства атрибутов под теми же номерами не совпадает с остальными производителями
smart_kingston.bin	- kingston (a400) - наибольший список атрибутов
smart_ocz.bin		- ocz (tl100/tr200)

списки и описания атрибутов:
smart_apacer.bin
0x09:  - Power on hours
0x0C:  - Power on/off cycles
0xA3:  - Max Erase Count
0xA4:  - Avg Erase Count
0xA6:  - Total Later Bad Blcok Count
0xA7:  - Protect Mode
0xA8:  - SATA PHY error count
0xAB:  - Program Fail Count
0xAC:  - Erase Failure Count
0xAF:  - Number of ECC Error
0xC0:  - Unexpected Power Loss Count
0xC2:  - Current Temp/Min Temp/Max Temp
0xE7:  - SSD life left
0xF1:  - Host Write (Sectors)

smart_default.bin
0x01:  - Number of ECC Error
0x09:  - Power on hours
0x0C:  - Power on/off cycles
0xA8:  - SATA PHY error count
0xAA:  - Total Early Bad Blcok Count/Total Later Bad Blcok Count
0xAD:  - Max Erase Cnt/Avg Erase Cnt
0xC0:  - Unexpected Power Loss Count
0xC2:  - Current Temp/Min Temp/Max Temp
0xDA:  - CRC Error Count
0xE7:  - SSD life left
0xF1:  - Host Write (GB)

smart_kingspec.bin
0x01:  - Number of ECC Error
0x05:  - Total Later Bad Blcok Count
0x09:  - Power on hours
0x0C:  - Power on/off cycles
0xA0:  - Read Fail Count
0xA1:  - Return All Zero Data
0xA3:  - Return All Zero Data
0xA4:  - Total Erase Count
0xA5:  - Max Erase Count
0xA6:  - min Erase Cnt
0xA7:  - Avg Erase Count
0xC0:  - Unexpected Power Loss Count
0xC2:  - Current Temp
0xC3:  - HB retry count
0xC4:  - ReadMoveTableCnt
0xF1:  - Host Write (65536 Sectors)
0xF2:  - Host Read (65536 Sectors)

smart_kingston.bin
0x01:  - Number of ECC Error
0x09:  - Power on hours
0x0C:  - Power on/off cycles
0x94:  - RS retry count
0x95:  - ?
0xA7:  - Protect Mode
0xA8:  - SATA PHY error count
0xA9:  - Bad Blcok Rate
0xAA:  - early bad block (Worst, Plane)
0xAC:  - Erase Failure Count
0xAD:  - Max Erase Cnt/Avg Erase Cnt
0xB5:  - Program Fail Count
0xB6:  - ?
0xBB:  - UNC Error Count
0xC0:  - Unexpected Power Loss Count
0xC2:  - Current Temp/Min Temp/Max Temp
0xC4:  - Total Later Bad Blcok Count
0xC7:  - SATA PHY error count
0xDA:  - CRC Error Count
0xE7:  - SSD life left
0xE9:  - NAND Write (GB)
0xF1:  - Host Write (GB)
0xF2:  - Host Read (GB)
0xF4:  - Avg Erase Count
0xF5:  - Max Erase Count
0xF6:  - ?

smart_ocz.bin
0x09:  - Power on hours
0x0C:  - Power on/off cycles
0xA7:  - Protect Mode
0xA8:  - SATA PHY error count
0xA9:  - ?
0xAD:  - ?
0xC0:  - Unexpected Power Loss Count
0xC2:  - Current Temp/Min Temp/Max Temp
0xF1:  - Host Write (65536 Sectors)
