Программа предназначена для восстановления работоспособности дисков на контроллере Phison 3110(S10), например Smartbuy Ignition4, после недачной попытки обновления версии прошивки программой Phison Toolbox разных версий.
Отличительными признаками такого состояния диска является название модели "PHISON SSD S10" и обьем, определяемый как 0 или 2MB.
Так же возможны массовые сообщения об ошибках обмена в журнале системы, и долгая ее загрузка при подключенном диске, вплоть до зависания.
Данные, в случае удачного восстановления, уничтожаются (впрочем, возможно их там уже нет изначально).

Системные требования - Windows XP/SP2 и выше, возможно использование x86 и x64 версий. Можно использовать Windows PE основанные на этих же версиях. Требуется запуск с правами администратора.
Для запуска необходимо определение диска системой, наименее проблемны для этого SATA режим дискового контроллера и драйвер "Standart Dual Channel PCI IDE", программа может работать и с другими драйверами, такими как Standart AHCI или Intel RST, но вероятность успешной загрузки системы с подключенным проблемным диском и его определения с ними ниже. Совместимость с драйверами контроллеров других производителей не проверялась. Наверняка не будет работать с драйверами контроллеров из раздела "SCSI and RAID controllers".
Так же возможна работа через некоторые usb-sata мосты, например asmedia asm105x/115x, jmicron jm[s]20329/539/578, initio inic1608 и некоторые другие.

Для запуска программе нужно указать номер диска в системе в виде параметра, его можно посмотреть в консоли "Управление компьютером"->"Управление дисками". Возможен запуск без параметров и ввод номера диска по запросу программы.
Например:
repairS10 2

В случае успешного прохождения проверок запрашивается подтверждение операции, требуется нажать "Y" и "Enter", для отказа любую другую кнопку.
После успешного выполнения операции требуется выключить и включить компьютер (или питание на ssd).

-------

This utility designed for repair Phison S10 based SSD, bricked by Phison Toolbox for firmware update, and will not help in other cases.
The drive in this state detected as "PHISON SSD S10" with capacity about 0 or 2MBytes.
System requirements: windows xp sp2 or above, x86 or x64, possible Windows PE environment.
Preferable using SATA mode of disk controller with "Standart Dual Chanel PCI IDE Controller" driver, but possible work in AHCI Mode with "Standart AHCI Controller" from MS or "Intel RST" driver.
Possible work via some usb-sata bridge, from asmedia, jmicron and some other.
Utility request disk number, which can be viewed in "Computer Managment"/"Disk Managment".
After successfully complete you should do a power cycle for SSD.
Run example (for drive #2):

repairS10 2
